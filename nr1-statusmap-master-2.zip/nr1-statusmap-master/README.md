# Status Map

![GitHub release (latest SemVer including pre-releases)](https://img.shields.io/github/v/release/newrelic/nr1-statusmap?include_prereleases&sort=semver) [![Snyk](https://snyk.io/test/github/newrelic/nr1-statusmap/badge.svg)](https://snyk.io/test/github/newrelic/nr1-statusmap)

## Usage
A high level dashboard that allows quick identification of problem areas in a easy to use and fun interface.

![Example](screenshots/screenshot.png)

## Open Source License

This project is distributed under the [Apache 2 license](LICENSE).


## What do you need to make this work?
* You need a background image a bit [like this one](nerdlets/statusmap-nerdlet/background.png)
* You need some queries that return values that you would like to display.
* A bit of patience plotting the panel and label positions over the image

## Configuration

### background.png
Create a background image and call it background.png and drop it into the nerdlet folder. You need to know the width and height of the image to add to the configuration below.

The remainder of the configuration is in the config object in the main component

### accountId
Put the account ID here.

### canvas
This object defines the canvas. Use the width and height of the image. When you start set the x/yOffset to zero. You can adjust this if you at a later date change the size of the image - it means you don't have to update all your panel coordinates :)

* width - width in pixels
* height - height in pixels
* xOffset - x offset in pixels
* yOffset - y offset in pixels

### panels
This is an array of all the panels you would like to render. Each panel is configured as follows:

* caption - The label to display
* data - an object defining how the data is treated
* * panelType - singleValue|columnValue (determines how threshold is calculated)
* * testField - the field from the query to test against threshold (careful sometimes this isnt what you expect, check the json response)
* * testValue - when panelType is columnValue then this indicates what value is considered good. All other values are considered bad.
* * threshold - defines the thresholds for colouring
* * * direction - Indicate which direction the threshold works: above|below
* * * warning - the value at which the warning state would be triggered
* * * critical - the value at which the critical state would be triggered
* * query - An NRQL query that returns the data
* label - specifies the label position
* * top, left - the y & x coordinates
* * right - if true the label is right aligned
* * showValue - if true a sub label is also displayed contiaing the value from the query
* * roundPlaces - if required specify the decimal places to round to for the value
* box - specifies the box positioning
* * top, left, width, height - posittioning and size in pixels
* link - defines the link
* * url - the url for the link 

### gauges
This is an array of gauges you would like to render. Each gauge is configured as follows:

* caption - the label to display beneath the gauge
* data - defines how the data is treated
* * precentField - the name of the field in the results that indicates a percentage
* * valueField - the name of the field in the results that appears a the value label
* * query - NRQL query exposing the above fields
* * suffix - an optional suffix to show next to the value label
* * formatter 0 a function that formats the value field
* link - link to link to
* * url - the url for the link

## Getting started

First, ensure that you have [Git](https://git-scm.com/book/en/v2/Getting-Started-Installing-Git) and [NPM](https://www.npmjs.com/get-npm) installed. If you're unsure whether you have one or both of them installed, run the following command(s) (If you have them installed these commands will return a version number, if not, the commands won't be recognized):

```bash
git --version
npm -v
```

Next, install the [NR1 CLI](https://one.newrelic.com/launcher/developer-center.launcher) by going to [this link](https://one.newrelic.com/launcher/developer-center.launcher) and following the instructions (5 minutes or less) to install and setup your New Relic development environment.

Next, to clone this repository and run the code locally against your New Relic data, execute the following command:

```bash
nr1 nerdpack:clone -r https://github.com/newrelic/nr1-statusmap.git
cd nr1-statusmap
nr1 nerdpack:serve
```

Visit [https://one.newrelic.com/?nerdpacks=local](https://one.newrelic.com/?nerdpacks=local), navigate to the Nerdpack, and :sparkles:

**Note: You will need to update the configuration to set your account ID and your own custom NRQL queries**

## Deploying this Nerdpack

Open a command prompt in the nerdpack's directory and run the following commands.

```bash
# If you need to create a new uuid for the account to which you're deploying this Nerdpack, use the following
# nr1 nerdpack:uuid -g [--profile=your_profile_name]
# to see a list of APIkeys / profiles available in your development environment, run nr1 credentials:list
nr1 nerdpack:publish [--profile=your_profile_name]
nr1 nerdpack:deploy [-c [DEV|BETA|STABLE]] [--profile=your_profile_name]
nr1 nerdpack:subscribe [-c [DEV|BETA|STABLE]] [--profile=your_profile_name]
```

Visit [https://one.newrelic.com](https://one.newrelic.com), navigate to the Nerdpack, and :sparkles:

# Support

New Relic has open-sourced this project. This project is provided AS-IS WITHOUT WARRANTY OR SUPPORT, although you can report issues and contribute to the project here on GitHub.

_Please do not report issues with this software to New Relic Global Technical Support._

## Community

New Relic hosts and moderates an online forum where customers can interact with New Relic employees as well as other customers to get help and share best practices. Like all official New Relic open source projects, there's a related Community topic in the New Relic Explorers Hub. You can find this project's topic/threads here:

https://discuss.newrelic.com/t/statusmap-nerdpack/82723
*(Note: URL subject to change before GA)*

## Issues / Enhancement Requests

Issues and enhancement requests can be submitted in the [Issues tab of this repository](../../issues). Please search for and review the existing open issues before submitting a new issue.

# Contributing

Contributions are welcome (and if you submit a Enhancement Request, expect to be invited to contribute it yourself :grin:). Please review our [Contributors Guide](CONTRIBUTING.md).

Keep in mind that when you submit your pull request, you'll need to sign the CLA via the click-through using CLA-Assistant. If you'd like to execute our corporate CLA, or if you have any questions, please drop us an email at opensource@newrelic.com.
