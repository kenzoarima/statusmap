import React from 'react';
import background from './background.png' 
import {Spinner, Icon, NerdGraphQuery, Tooltip} from 'nr1';
import PropTypes from 'prop-types';
import Chart from "react-apexcharts";
import Countdown from 'react-countdown-now';

/*
*  Gauge Component 
*  Renders a speedometer style gauge.
*
* @prop {String} value    - The value to display
* @prop {String} suffix   - A suffix to add to the value
* @prop {Number} percent  - A percentage value that indicates progress on the gauge
* @prop {String} label    - The label to display beneath the gauge
* @prop {String} link     - A link url
*
*/
class Gauge extends React.Component {
  static propTypes = {
      suffix: PropTypes.string,
      value: PropTypes.any.isRequired,
      percent: PropTypes.number.isRequired,
      label: PropTypes.string.isRequired,
      link: PropTypes.string.isRequired
   }

  render() {
    let suffix=this.props.suffix ? this.props.suffix : ""
    let gaugeOptions = {
      colors: ["#438787"],
      
      plotOptions: {
        radialBar: {
          startAngle: -100,
          endAngle: 100,
          track: {
            background: '#333',
            startAngle: -100,
            endAngle: 100,
            dropShadow: {
                enabled: true,
                top: 0,
                left: 0,
                blur: 3,
                color: '#000',
                opacity: 0.35
            }
          },
          dataLabels: {
            name: {
              show: true,
              fontSize: "20px",
              color: "black",
              offsetY: -10,
              fontFamily: "'Courier New', Courier, monospace",
              fontWeight: "bold"
              
            },
            value: {
              fontSize: "14px",
              show: false,
              offsetY: -10,
              fontFamily: "'Courier New', Courier, monospace",
              fontWeight: "bold",
              formatter: function (val) {
                return val + suffix
              }
              
            }
          }
        }
      },
      fill: {
        type: "solid",
        opacity: 1,
      },
      stroke: {
        lineCap: "butt"
      },
      labels: [this.props.value]
    };

    return(<div className="gaugeBlock" > 
        <Chart
          options={gaugeOptions}
          series={[this.props.percent]}
          width="340"
          type="radialBar"
        /> 
        <div className="gaugeBlockLabel"><a className="gaugeLabelLink" href={this.props.link} target="_blank">{this.props.label}</a></div>
      </div>)
  }
}

/*
*  ColorBox Component 
*  A box to render over the background image
*
* @prop {Number} top        - The Y coordinate in px
* @prop {Number} left       - The X coordinate in px
* @prop {Number} width      - The width in px
* @prop {Number} height     - The height in px
* @prop {String} alertType  - The alert type, one of: normal|warning|critical
* @prop {String} link       - An http link to link to (optional)
* @prop {String} tooltip    - Text for tool tip (optional)
*
*/
class ColorBox extends React.Component {
  static propTypes = {
    top: PropTypes.number.isRequired,
    left: PropTypes.number.isRequired,
    width: PropTypes.number.isRequired,
    height: PropTypes.number.isRequired,
    alertType: PropTypes.string.isRequired,
    link: PropTypes.string,
    tooltip: PropTypes.string
  }
  render() {
    let className = "colorBox normalBox"
    if(this.props.alertType === "critical") { className="colorBox criticalBox" }
    if(this.props.alertType === "warning") { className="colorBox warningBox" } 
    
    let openLink=()=>{}
    if(this.props.link && this.props.link!=="") {
      openLink = () => {
        window.open(this.props.link);
      }
    }

    let innerContent=<div style={{height:`${this.props.height}px`,width:`${this.props.width}px`}} onClick={openLink}> </div>
    if(this.props.tooltip && this.props.tooltip!="") {
      //hack to force tooltip to be wide
      let spacer="\n\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0"
      innerContent=<Tooltip text={this.props.tooltip+spacer}>{innerContent}</Tooltip>
    }
    

    return (
       <div className={className} style={{
        top:`${this.props.top}px`, 
        left:`${this.props.left}px`, 
        height:`${this.props.height}px`, 
        width:`${this.props.width}px`
      }} >
        {innerContent}
      </div>   
    );
  }
}


/*
*  LineLabel Component 
*  A label to be rendered over the image
*
* @prop {Number} top          - The Y coordinate in px
* @prop {Number} left         - The X coordinate in px
* @prop {Bool} right          - Indicates the label should be right aligned
* @prop {String} label        - The label text
* @prop {String} alertType    - The alert type, one of: normal|warning|critical
* @prop {String} extraLabel   - An extra sub label displayed next to the label, usually a value
* @prop {String} link         - A link url
*
*/
class LineLabel extends React.Component {
  static propTypes = {
    top: PropTypes.number.isRequired,
    left: PropTypes.number.isRequired,
    right: PropTypes.bool,
    alertType: PropTypes.string.isRequired,
    extraLabel: PropTypes.string,
    link: PropTypes.string,
    label: PropTypes.string.isRequired
  }
  render() {
    let className = this.props.right ? "lineLabel lineLabelRight" : "lineLabel"
    let icon = <Icon className="labelIconNormal" type={Icon.TYPE.INTERFACE__SIGN__CHECKMARK__V_ALTERNATE} color=""/>
    if(this.props.alertType === "critical") { 
      className+=" criticalLabel" 
      icon = <Icon className="labelIconCritical" type={Icon.TYPE.INTERFACE__SIGN__TIMES__V_ALTERNATE} color=""/>
    }
    if(this.props.alertType === "warning") { 
      className+=" warningLabel" 
      icon = <Icon className="labelIconWarning" type={Icon.TYPE.INTERFACE__SIGN__EXCLAMATION__V_ALTERNATE} color=""/>
    } 

    let extra=""
    if(this.props.extraLabel && this.props.extraLabel.extraLabel != "") {
      extra=<span className="extraLabel"> {this.props.extraLabel}</span>
    }
    
    return (
      <div className={className} style={{
        top:`${this.props.top}px`, 
        left:`${this.props.left}px`
      }} >{icon} <a className="labelLink" href={this.props.link ? this.props.link : "#"} target={this.props.link ? "_blank" : "" }>{this.props.label}{extra}</a></div>
    );
  }
}


export default class StatusMap extends React.Component {
    constructor(props) {
      super(props);
      this.state = {}
      this.config= {
        "accountId": 1606862,
        "canvas": {
          "width": 1044,
          "height": 729,
          "xOffset": 0,
          "yOffset": 0
        },
        panels : [
          {
            "caption": "Synthetics",
            "data" : {
              "panelType": "columnValue",
              "testField": "result",
              "testValue": "SUCCESS",
              "threshold" : {
                "direction": "below",
                "warning": 99,
                "critical": 80
              },
              "query": "SELECT latest(result) as 'result' from SyntheticCheck facet monitorName since 24 hours ago limit 200"
            },              
            "label": { top: 410, left: 40, right: false },
            "box" : { top: 307, left: 194, height: 153, width:78},
            "link":  {url:"https://one.newrelic.com/launcher/5325190d-7430-4b9c-9a47-994c1ab36612.synthstatus-launcher#launcher=eyJ0aW1lUmFuZ2UiOnsiYmVnaW5fdGltZSI6bnVsbCwiZW5kX3RpbWUiOm51bGwsImR1cmF0aW9uIjoxODAwMDAwfX0=&pane=eyJuZXJkbGV0SWQiOiI1MzI1MTkwZC03NDMwLTRiOWMtOWE0Ny05OTRjMWFiMzY2MTIuc3ludGhzdGF0dXMtbmVyZGxldCJ9"},
            "tooltip": "An example tooltip that can convey some information about the meaning of this box and its thresholds"
          },
          {
            "caption": "Web Apdex",
            "data" : {
              "panelType": "singleValue",
              "testField": "score",
              "threshold" : {
                "direction": "below",
                "warning": 0.95,
                "critical": 0.8
              },
              "query": "SELECT apdex(duration,0.37) from Transaction where appName='WebPortal' since 5 minutes ago"
            },              
            "label": { top: 240, left: 40, right: false, showValue: true, roundPlaces: 2 },
            "box" : { top: 307, left: 298, height: 153, width:78},
            "link":  {url:"https://rpm.newrelic.com/accounts/1606862/applications/43192210"},
            "tooltip": "An example tooltip that can convey some information about the meaning of this box and its thresholds"
          },
          {
            "caption": "Web Error Rate",
            "data" : {
              "panelType": "singleValue",
              "testField": "ErrorRate",
              "threshold" : {
                "direction": "above",
                "warning": 0.5,
                "critical": 1
              },
              "query": "SELECT percentage(count(*), where error is null) as 'ErrorRate' from Transaction, TransactionError where appName='WebPortal' since 5 minutes ago"
            },              
            "label": { top: 236, left: 479, right: true, showValue: true, roundPlaces:2 },
            "box" : { top: 307, left: 396, height: 153, width:78},
            "link":  {url:"https://rpm.newrelic.com/accounts/1606862/applications/43192210/traced_errors"},
            "tooltip": "An example tooltip that can convey some information about the meaning of this box and its thresholds"
          },
          {
            "caption": "Infrastructure",
            "data" : {
              "panelType": "singleValue",
              "testField": "ErrorRate",
              "threshold" : {
                "direction": "above",
                "warning": 10,
                "critical": 20
              },
              "query": "SELECT percentage(count(*), where error is null) as 'ErrorRate' from Transaction, TransactionError where appName='WebPortal' since 5 minutes ago"
            },              
            "label": { top: 340, left: 645, right: true },
            "box" : { top: 417, left: 536, height: 80, width:88},
            "link":  {url:"https://infrastructure.newrelic.com/accounts/1606862"},
            "tooltip": "An example tooltip that can convey some information about the meaning of this box and its thresholds"
          },
          {
            "caption": "Response Times",
            "data" : {
              "panelType": "singleValue",
              "testField": "average",
              "threshold" : {
                "direction": "above",
                "warning": 2,
                "critical": 4
              },
              "query": "SELECT average(duration) as average from PageView since 5 minutes ago where appName='WebPortal'"
            },                    
            "label": { top: 699, left: 433, right: false,showValue: true, roundPlaces:2 },
            "box" : { top: 526, left: 651, height: 55, width:139},
            "link":  {url:"https://rpm.newrelic.com/accounts/1606862/browser/43192210#/?percentile=50&selectedChart=spa_response&_k=4ijbui"},
            "tooltip": "Indicates the pageView duration. Warning if above 2, critical if above 4",
            "tooltip": "An example tooltip that can convey some information about the meaning of this box and its thresholds"
          },
          {
            "caption": "Crash Rate",
            "data" : {
              "panelType": "singleValue",
              "testField": "CrashRate",
              "threshold" : {
                "direction": "above",
                "warning": 5,
                "critical": 10
              },
              "query": "SELECT percentage(uniqueCount(sessionId), WHERE category = 'Crash') as `CrashRate` FROM MobileSession, MobileCrash WHERE (appId = 61690778 OR appVersionId = 61690778) WHERE crashFingerprint NOT IN ('f702225e762466851f571932c761f2b7-1606862-61691533','f702225e762466851f571932c761f2b7-1606862-61691356','9006561898ba1517ab7b98cf3c5e1c28-1606862-61691560','9006561898ba1517ab7b98cf3c5e1c28-1606862-61691356','f72dac2881e2d35e9c60bbc1c8781b59-1606862-61691356') since 5 minutes ago"
            },                    
            "label": { top: 699, left: 40, right: false, showValue: true, roundPlaces:2 },
            "box" : { top: 532, left: 176, height: 51, width:334},
            "link":  {url:"https://rpm.newrelic.com/accounts/1606862/mobile/61690778/crash_analysis"},
            "tooltip": "Indicates the pageView duration. Warning if above 2, critical if above 4",
            "tooltip": "An example tooltip that can convey some information about the meaning of this box and its thresholds"
          }
          
        ],
        gauges: [
          {
            "caption": "Transactions",
            "data" : {
              "percentField": "percent",
              "valueField": "transactions",
              "query": "SELECT (count(*)/100000)*100 as 'percent', count(*)/1000 as 'transactions' from Transaction  since 5 minutes ago" ,
              "suffix": "%",
              "formatter": function(v) {
                return v.toFixed(2)+"k"
              }
            },
            "link": { url:"https://rpm.newrelic.com/accounts/1909250/applications?filterBy=Environment:Production" }   
          },
          {
            "caption": "Errors",
            "data" : {
              "percentField": "percent",
              "valueField": "transactions",
              "query": "SELECT (count(*)/200)*100 as 'percent', count(*) as 'transactions' from TransactionError  since 5 minutes ago" ,
              "suffix": "%",
              "formatter": function(v) {
                return v.toFixed(0)+""
              }
            },
            "link": { url:"https://rpm.newrelic.com/accounts/1909250/applications?filterBy=Environment:Production" }   
          },
          {
            "caption": "Mobile",
            "data" : {
              "percentField": "percent",
              "valueField": "transactions",
              "query": "SELECT (count(*)/1000)*100 as 'percent', count(*) as 'transactions' from Mobile  since 5 minutes ago" ,
              "suffix": "%",
              "formatter": function(v) {
                return v.toFixed(2)+"k"
              }
            },
            "link": { url:"https://rpm.newrelic.com/accounts/1909250/applications?filterBy=Environment:Production" }   
          }

        ]
      }

      //genereate unique references for each panel/gauge query
      let queryCount=0;
      if(this.config.panels) {
        this.config.panels.forEach((q)=>{
          q.ref="panel_"+queryCount++;
        })
      }
      if(this.config.gauges) {
        this.config.gauges.forEach((q)=>{
          q.ref="gauge_"+queryCount++;
        })
      }

      this.getData = this.getData.bind(this)
    }

    async componentDidMount() {
        this.getData()
        this.interval = setInterval(() => this.getData(), 1000*60*1) //auto refresh 1 minute;
    }
    
    componentWillUnmount() {
        clearInterval(this.interval);
    }

    componentDidUpdate() {
        if (this.state.queryData === null) {
            this.getOverallLatest()
        }
    }


    /*
    *
    * getData()
    * 
    * Gets the data via graphql query
    */
    getData() {
      let query = `
          query($id: Int!) {
              actor {
                  account(id: $id) {`

                    //add the panels provided
                    if(this.config.panels) {
                      this.config.panels.forEach((panel) => {
                        query+=` ${panel.ref}: nrql(query: "${panel.data.query}") { results } `
                      });  
                    }
                    
                    //add the gauges provided
                    if(this.config.gauges) {
                      this.config.gauges.forEach((gauge) => {
                        query+=` ${gauge.ref}: nrql(query: "${gauge.data.query}") { results } `
                      });    
                    }
      query+=`
                  }
              }
          }
      `;

      const variables = {
          id: this.config.accountId
      };


      const q = NerdGraphQuery.query({ query: query, variables: variables });
      q.then(results => {                
          let returnObj = {}
          if(this.config.panels) {
            this.config.panels.forEach((q) => {  //add the dynamic periods
                returnObj[q.ref]=results.data.actor.account[q.ref].results
            })
          }
          if(this.config.gauges) {
            this.config.gauges.forEach((q) => {  //add the dynamic periods
              returnObj[q.ref]=results.data.actor.account[q.ref].results
            })
          }
          
          this.setState({ queryData: returnObj})
      }).catch((error) => { console.log(error); })
    }


    /*
    * extraLabel()
    * Formats the extra label
    * 
    * @prop {Bool} showValue        - Inidcates if it should be shown at all
    * @prop {Number} val            - The value to display
    * @prop {Number} roundPlaces    - The number of decimal places to round to (optional)
    * @prop {String} suffix         - A suffix to append to the value (optional)
    */
    //formats the extra label
    extraLabel(showValue,val,roundPlaces,suffix) {
      if(showValue) {
        if(roundPlaces!=undefined) {
          val = parseFloat(val).toFixed(roundPlaces)
        } 
        if(suffix) {
          val=val+=suffix
        }
        return `[${val}]`
      } else {
        return null
      }
    }


    /*
    * panelColumnValue()
    * Draws a panel based on a data set. Criticality is determined by the percent of the results matchign  condition.
    * For example, if you select the latest() values from a table you can use this type to show a warning if x% dont match a given value. 
    * 
    * @prop {Object} canvasConfig   - The configuration of the canvas itself (this.config.canvas)
    * @prop {Number} data           - The data set
    * @prop {Object} panelConfig    - The current panel configuration
    */
    panelColumnValue(canvasConfig,data,panelConfig) {
      let total = 0
      data.forEach((result)=>{
        if(result[panelConfig.data.testField] === panelConfig.data.testValue) {
          total++
        }
      })

      let percent = (total / data.length) * 100

      let alertType = ""
      if(panelConfig.data.threshold.direction === "below") {
        if( percent <= panelConfig.data.threshold.critical) { alertType="critical"}
        else if( percent <= panelConfig.data.threshold.warning) { alertType="warning"}
      } else {
        if( percent >= panelConfig.data.threshold.critical) { alertType="critical"}
        else if( percent >= panelConfig.data.threshold.warning) { alertType="warning"}
      }

      let extraLabel=this.extraLabel(panelConfig.label.showValue,percent,panelConfig.label.roundPlaces,panelConfig.label.valueSuffix)

      return(<React.Fragment key={`${panelConfig.ref}`}>
        <LineLabel top={panelConfig.label.top+canvasConfig.yOffset} left={panelConfig.label.left+canvasConfig.xOffset} label={panelConfig.caption} alertType={alertType} right={panelConfig.label.right ? true : false} extraLabel={extraLabel} link={panelConfig.link ? panelConfig.link.url : ""} />
        <ColorBox top={panelConfig.box.top+canvasConfig.yOffset} left={panelConfig.box.left+canvasConfig.xOffset} height={panelConfig.box.height} width={panelConfig.box.width} alertType={alertType} link={panelConfig.link ? panelConfig.link.url : ""} tooltip={panelConfig.tooltip ? panelConfig.tooltip : ""}/>
      </React.Fragment>)
    }

    /*
    * panelSingleValue()
    * Draws a panel based on a single value in a query.
    * 
    * @prop {Object} canvasConfig   - The configuration of the canvas itself (this.config.canvas)
    * @prop {Number} data           - The data set
    * @prop {Object} panelConfig    - The current panel configuration
    */
    panelSingleValue(canvasConfig,data,panelConfig) {
      let alertType = ""
      let val = data[0][panelConfig.data.testField]

    
      if(panelConfig.data.threshold.direction === "below") {
        if( val <= panelConfig.data.threshold.critical) { alertType="critical"}
          else if( val <= panelConfig.data.threshold.warning) { alertType="warning"}
      } else {
          if( val >= panelConfig.data.threshold.critical) { alertType="critical"}
          else if( val >= panelConfig.data.threshold.warning) { alertType="warning"}
      }

      let extraLabel=this.extraLabel(panelConfig.label.showValue,val,panelConfig.label.roundPlaces,panelConfig.label.valueSuffix)

      return(<React.Fragment key={`${panelConfig.ref}`}>
        <LineLabel top={panelConfig.label.top+canvasConfig.yOffset} left={panelConfig.label.left+canvasConfig.xOffset} label={panelConfig.caption} alertType={alertType} right={panelConfig.label.right ? true : false} extraLabel={extraLabel} link={panelConfig.link ? panelConfig.link.url : ""}/>
        <ColorBox top={panelConfig.box.top+canvasConfig.yOffset} left={panelConfig.box.left+canvasConfig.xOffset} height={panelConfig.box.height} width={panelConfig.box.width} alertType={alertType} link={panelConfig.link ? panelConfig.link.url : ""} tooltip={panelConfig.tooltip ? panelConfig.tooltip : ""}/>
      </React.Fragment>)
    }


    /*
    * gaugeValue()
    * Draws a guage.
    * 
    * @prop {Object} data         - The configuration of the canvas itself (this.config.canvas)
    * @prop {Number} gaugeConfig  - The guage config
    */
    gaugeValue(data,gaugeConfig) {
      let fmtValue=gaugeConfig.data.formatter(data[0][gaugeConfig.data.valueField])
      return <Gauge key={gaugeConfig.ref} percent={data[0][gaugeConfig.data.percentField]} value={fmtValue} label={gaugeConfig.caption} suffix="" link={gaugeConfig.link.url}/>;
    }

    render() {

      const { queryData } = this.state;

      let mapzone = <Spinner />
      if(queryData && this.config.panels ) {

        //Iterate over the configuration to draw all the panels
        let annotations = []
        this.config.panels.forEach((panel) => {
          if(panel.data.panelType==="columnValue") {
            annotations.push(this.panelColumnValue(this.config.canvas,queryData[panel.ref],panel))
          } 
          else if (panel.data.panelType==="singleValue") {
            annotations.push(this.panelSingleValue(this.config.canvas,queryData[panel.ref],panel))
          }
        })
        mapzone =<div className="imageContainer" style={{backgroundImage:`url(${background})`, width:`${this.config.canvas.width}px`, height:`${this.config.canvas.height}px`}}> 
                    {annotations}
                </div>;
      }


      let gaugezone = <Spinner />
      if(queryData && this.config.gauges) {
        //Iterate over the configuration to draw all the gauges
        let gauges = []
        this.config.gauges.forEach((gauge) => {
            gauges.push(this.gaugeValue(queryData[gauge.ref],gauge))
        })
        gaugezone =<div className="gaugeArea">{gauges}</div>;
      }


      //Countdown configuration
      const countDownRenderer = ({ days, hours, minutes, seconds, completed }) => {
        if (completed) {
          // Render a completed state
          return <>Unknown...</>;
        } else {
          // Render a countdown
          return <span className="countdown">
            {(days+"").padStart(2, '0')}<span className="countdownLabel">D</span>
            {(hours+"").padStart(2, '0')}<span className="countdownLabel">H</span>
            {(minutes+"").padStart(2, '0')}<span className="countdownLabel">M</span>
            {(seconds+"").padStart(2, '0')}<span className="countdownLabel">S</span></span>;
        }
      };
      const countDate=new Date('November 29, 2019 19:00:00 GMT');

      
      
      return (<><div style={{width:`${this.config.canvas.width}px`, height:`${this.config.canvas.height}px`}}>
        <div className="headerArea">
          <div className="headerLabel"><span className="headerLabelHeading">Environment:</span>Production Demotron</div>
          <div className="headerLabel"><span className="headerLabelHeading">Black Friday:</span><Countdown
            date={countDate}
            intervalDelay={0}
            precision={3}
            renderer={countDownRenderer}
          /> Fri 29th Nov, 7pm</div>
        </div>
        {mapzone}
        </div>
        {gaugezone}
      </>);

    }
}
